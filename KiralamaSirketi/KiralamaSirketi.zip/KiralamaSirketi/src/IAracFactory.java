public interface IAracFactory {
    public IMotor motorUret();
    public ILastik lastikUret();
    public IIcMekan icMekanUret();
}
