public class SedanIcMekan implements IIcMekan{

    @Override
    public void icMekanUret() {
        System.out.println("İç mekan üretildi");
     }
}
