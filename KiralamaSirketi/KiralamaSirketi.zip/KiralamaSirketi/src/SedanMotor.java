public class SedanMotor implements IMotor{

    @Override
    public void motorUret() {
        System.out.println("Motor Üretildi");
    }
}
