public class SporArabaMotor implements IMotor{
    @Override
    public void motorUret(){

    }
}
