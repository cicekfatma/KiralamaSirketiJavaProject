public class SUVLastik implements ILastik{

    @Override
    public void lastikUret() {

    }
}
