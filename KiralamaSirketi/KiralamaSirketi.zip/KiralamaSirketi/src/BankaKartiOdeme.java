public class BankaKartiOdeme implements IOdemeStratejisi{

    @Override
    public void OdemeYap(double miktar) {

    }
}
