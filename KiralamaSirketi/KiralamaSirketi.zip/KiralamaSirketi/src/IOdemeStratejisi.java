public interface IOdemeStratejisi {
    public void OdemeYap(double miktar);
}
