public class SUVIcMekan implements IIcMekan{

    @Override
    public void icMekanUret() {

    }
}
