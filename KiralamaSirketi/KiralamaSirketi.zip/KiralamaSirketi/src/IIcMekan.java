public interface IIcMekan {
    public void icMekanUret();
}
