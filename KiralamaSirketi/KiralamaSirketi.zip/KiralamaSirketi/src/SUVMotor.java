public class SUVMotor implements IMotor{
    @Override
    public void motorUret() {
    }
}
