public class SporArabaIcMekan implements IIcMekan{

    @Override
    public void icMekanUret() {

    }
}
