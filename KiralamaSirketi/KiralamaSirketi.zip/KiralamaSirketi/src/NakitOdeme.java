public class NakitOdeme implements IOdemeStratejisi{

    @Override
    public void OdemeYap(double miktar) {

    }
}
