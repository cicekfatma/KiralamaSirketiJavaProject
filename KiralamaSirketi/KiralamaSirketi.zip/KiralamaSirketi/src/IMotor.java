public interface IMotor {
    public void motorUret();
}
