public class KrediKartiOdeme implements IOdemeStratejisi{
    @Override
    public void OdemeYap(double miktar){


    }
}
