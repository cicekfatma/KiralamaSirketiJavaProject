public class SporArabaLastik implements ILastik{

    @Override
    public void lastikUret() {

    }
}
