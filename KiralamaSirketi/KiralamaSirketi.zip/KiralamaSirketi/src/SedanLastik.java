public class SedanLastik implements ILastik{


    @Override
    public void lastikUret() {
        System.out.println("Lastik Üretildi");
    }
}
