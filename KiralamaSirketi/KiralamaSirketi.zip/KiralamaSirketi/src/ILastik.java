public interface ILastik {
    public void lastikUret();
}
